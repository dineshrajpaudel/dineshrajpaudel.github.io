from flask import Flask, render_template, request, redirect,make_response, url_for, flash,session
import socket 
import os
from flask_mysqldb import MySQL
from flask_session import Session
from datetime import datetime
import json
from os import path
import math
from werkzeug.utils import secure_filename





app = Flask(__name__)
app.secret_key = 'many random bytes'
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'dineshrajpaudel'
app.config['MYSQL_PASSWORD'] = 'Dinesh@2000'
app.config['MYSQL_DB'] = 'test'
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}
Session(app)

mysql = MySQL(app)



@app.route("/")
def index():
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM post")
    data = cur.fetchall()
    cur.close()     
    return render_template('index.html',result=data)     




@app.route("/dashboard")
def dashboard():
    Id=session.get("id")
    if not session.get("email"):
        return redirect("/login")
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()


    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM post")
    data = cur.fetchall()
    cur.close()     
    return render_template('Admin/index.html',result=data, results=dataId )     








username="dineshrajpaudel84@gmail.com"
Passwords="Dinesh@2000"
#Login
@app.route("/login", methods=["POST", "GET"])
def login():
    if session.get("email"):
        return redirect("/dashboard")  
    id=""
    Email=""
    password=""
    if request.method == "POST":
        # username = request.form['email']
        # Passwords = request.form['password']
    
        remember=request.form.get('remember')
        cur = mysql.connection.cursor()
        cur.execute("""
                   SELECT * from users
                   WHERE email=%s and password=%s
                """, (username,Passwords,))
        data = cur.fetchall()
        cur.close() 
        for details in data:
                    id=f"{details[0]}"
                    Email=details[2]
                    password=details[6] 
                    session["id"] =id       

        if Email!=username:
             flash("")
             flash("Username doesn't exist.") 
        elif Email==username and password!=Passwords:
                 flash(username)
                 flash("Your password is incorrect.") 

        elif remember=="on":
               response = make_response(f"The Cookie has been Set Dinesh Raj Paudel")
               expire_date = datetime.datetime.now()
               expire_date = expire_date + datetime.timedelta(days=90)
               response.set_cookie('Username',username, expires=expire_date)
               response.set_cookie('Password',Passwords,expires=expire_date)
               return "Cookie is set"
            #    return redirect("/login")

        else:
            session["email"] = request.form.get("email")
            cur = mysql.connection.cursor()
            cur.execute("""
                   UPDATE users
                   SET login_date=%s
                   WHERE id=%s
                """, (datetime.now(),id))
            mysql.connection.commit()  
        return redirect("/dashboard")
    return render_template('Admin/Pages/login.html')    

#Logout
@app.route("/logout")
def logout():
        id=1   
        session["email"] = None
        session["password"] = None
        cur = mysql.connection.cursor()
        cur.execute("""
                   UPDATE users
                   SET logout_date=%s
                   WHERE id=%s
                """, (datetime.now(),id))
        mysql.connection.commit()
        return redirect("/dashboard")



#Register
@app.route("/register")
def register():
    if session.get("email"):
        return redirect("/login")
    return render_template('Admin/Pages/create-account.html') 
   

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

#Insert Users Form
@app.route("/insertregistration_form", methods=["POST", "GET"])
def insertForm():
    if request.method == "POST":
        fname = request.form['fname']
        lname = request.form['lname']
        email = request.form['email']
        address = request.form['address']
        dob = request.form['dob']
        phone = request.form['phone']
        Password = request.form['password']
        repassword = request.form['repassword']
        file = request.files['file']
        path="static/Admin/Uploads/Profile"
        isExist = os.path.exists(path)
       
    
        if not isExist:
         os.mkdir(path)
        if file and allowed_file(file.filename):
                   filename = secure_filename(file.filename)
                   file.save(os.path.join(path, filename))
        else:
               flash("File is not a image")
               flash(fname)
               flash(lname)
               flash(email)
               flash(address)
               flash(dob)
               flash(phone)
               flash(Password)
               flash(repassword)
               return redirect('/register')           
        if Password!=repassword:
             flash("Password doesn't match.") 
             flash(fname)
             flash(lname)
             flash(email)
             flash(address)
             flash(dob)
             flash(phone)
             
             return redirect('/register')
        else:
           cur = mysql.connection.cursor()
           cur.execute("""
                  SELECT * from users
                   WHERE users_type="admin"
                """)
           data = cur.fetchall()
           cur.close() 
           if(data):
            name=fname+" "+lname
            flash("")
            flash("Data Inserted Successfully")
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO users (name, email,address,dob,phone,password,file,users_type) VALUES (%s, %s,%s,%s,%s,%s,%s,%s)", (name, email,address,dob,phone,Password ,filename,"user"))
            mysql.connection.commit()

           else:
            name=fname+" "+lname
            flash("")
            flash("Data Inserted Successfully")
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO users (name, email,address,dob,phone,password,file,users_type) VALUES (%s, %s,%s,%s,%s,%s,%s,%s)", (name, email,address,dob,phone,Password,filename,"admin"))
            mysql.connection.commit() 
    return redirect("/dashboard")


  #Data Tables  
@app.route('/dataTables')
def dataTables():
    if not session.get("email"):
        return redirect("/login")
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users")
    data = cur.fetchall()
    cur.close()


    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()     
    return render_template('Admin/datas.html',result=data,results=dataId)   
     
  


#View users Profile
@app.route('/usersView/<id>')
def usersview(id):
       if not session.get("email"):
           return redirect("/login")

       Id=session.get("id")    
       cur = mysql.connection.cursor()
       cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
       dataId = cur.fetchall()
       cur.close() 

       cur = mysql.connection.cursor()
       cur.execute("SELECT  * FROM users")
       data = cur.fetchall()
       cur.close()
       cur = mysql.connection.cursor()
       cur.execute("SELECT  * FROM users WHERE id=%s", (id,))
       data = cur.fetchall()
       cur.close() 
       return render_template('Admin/view.html', result=data,results=dataId )

#Edit User Form
@app.route('/usersEdit/<id>')
def usersEdit(id):
       cur = mysql.connection.cursor()
       cur.execute("SELECT  * FROM users WHERE id=%s", (id,))
       data = cur.fetchall()
       cur.close() 
       return render_template('Admin/Pages/create-account.html', result=data )

#Update
@app.route('/usersUpdate',methods=['POST','GET'])
def usersUpdate():
    if request.method == 'POST':
        id = request.form['id']
        name = request.form['name']
        email = request.form['email']
        address = request.form['address']
        dob = request.form['dob']
        phone = request.form['phone']
        password = request.form['password']
        repassword = request.form['repassword']
        if password!=repassword:
             flash("Password doesnot match.") 
             flash(name)
             flash(email)
             flash(address)
             flash(dob)
             flash(phone)
             
             return redirect('/register')
        # return  "{} {} {} {}".format(id,name,email,subject,message) 
        else:
            cur = mysql.connection.cursor()
            cur.execute("""
                   UPDATE users
                   SET name=%s,email=%s,address=%s,dob=%s,phone=%s,password=%s,update_time=%s
                   WHERE id=%s
                """, (name, email,address,dob,phone,password,datetime.now(),id))
            flash("Data Updated Successfully")
            mysql.connection.commit()
            return redirect("/dataTables")



#Delete
@app.route('/usersDelete/<id>', methods = ['GET'])
def usersDelete(id):
    # return id
    flash("Record Has Been Deleted Successfully")
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM users WHERE id=%s", (id,))
    mysql.connection.commit()
    cur.close() 
    return redirect("/dataTables")


  #Search Users
@app.route('/search',methods=['POST','GET'])
def search():
     if request.method == 'POST':
               name = request.form['search']
               if not session.get("email"):
                   return redirect("/login")
               
               Id=session.get("id")    
               cur = mysql.connection.cursor()
               cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
               dataId = cur.fetchall()
               cur.close()    
              
               cur = mysql.connection.cursor()
               searching= "%"+name+"%"
               cur.execute("SELECT * from users where name LIKE %s", [searching])
               data = cur.fetchall()
               cur.close() 
               return render_template('Admin/datas.html', result=data,results=dataId )  
     return redirect("/dataTables")




#Forget-password
@app.route('/forget')
def forget():
    return render_template('Admin/Pages/forgot-password.html')  







#Create Invoice
@app.route('/make_invoice')
def make_invoice():
    if not session.get("email"):
        return redirect("/login")
    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()     
    return render_template('Admin/Invoice/make_invoice.html',datas=dataId)  



#Create Invoice
@app.route('/makeInvoice', methods=["POST", "GET"])
def makeInvoice():
    if not session.get("email"):
        return redirect("/login")

    if request.method == "POST": 
        name = request.form['fname']
        email = request.form['email']
        address = request.form['address']
        cdate= request.form['cdate']
        oid = request.form['oid']
        payment_date = request.form['payment_date']
        account = request.form['account']
        product = request.form['product']
        price = request.form['price']
        desc=request.form['desc']
        subtotal = request.form['subtotal']
        phone = request.form['phone']
        tax=int(subtotal)*13/100
        shiping=int(subtotal)*2/100
        Total=int(subtotal)+tax+shiping  
        # return f"{subtotal} {tax} {shiping} {Total}"
        dictionary = {
          "Name":name,
          "Email":email,
          "Address":address,
          "Create_Date":cdate,
          "Phone":phone,
          "order_Id":oid,
          "Payment_Date":payment_date,
          "Account":account,
          "product":product,
          "price":price,
          "Description":desc,
          "Sub Total":subtotal,
          "Tax":tax,
          "Shiping":shiping,
          "Total":Total
        }
        json_object = json.dumps(dictionary, indent=4)
        with open("invoice.json", "w") as outfile:
            outfile.write(json_object)
    
    return redirect("/invoice")  
 




    # return render_template('Admin/Invoice/invoice.html',results=dataId)      
     
#Invoice
@app.route('/invoice')
def invoice():
    if not session.get("email"):
        return redirect("/login")
    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()  

    with open('invoice.json', 'r') as openfile:
	                json_data = json.load(openfile)
    print(json_data)     
    return render_template('Admin/Invoice/invoice.html',results=dataId,jsonData=json_data)     

#Invoice
@app.route('/invoicePrint')
def invoicePrint():
    if not session.get("email"):
        return redirect("/login")
    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()  
    with open('invoice.json', 'r') as openfile:
	                json_data = json.load(openfile)
    print(json_data)     
    return render_template('Admin/Invoice/invoice-print.html',results=dataId,jsonData=json_data)                
 

#Profile
@app.route('/profile')
def profile():
    if not session.get("email"):
        return redirect("/login")
    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()             
    return render_template('Admin/profile.html',results=dataId) 

#Project
@app.route('/projects')
def projects():
    if not session.get("email"):
        return redirect("/login")
    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()             
    return render_template('Admin/projects.html',results=dataId) 

#Project Add
@app.route('/projectAdd')
def projectAdd():
    if not session.get("email"):
        return redirect("/login")
    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()             
    return render_template('Admin/project-add.html',results=dataId) 

#Project Edit
@app.route('/projectEdit')
def projectEdit():
    if not session.get("email"):
        return redirect("/login")
    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()             
    return render_template('Admin/project-edit.html',results=dataId) 

#Project Edit
@app.route('/projectDetail')
def projectDetail():
    if not session.get("email"):
        return redirect("/login")
    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()             
    return render_template('Admin/project-contactUs.html',results=dataId) 



@app.route('/post')
def post():
    if not session.get("email"):
        return redirect("/login")
    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()             
    return render_template('Admin/post.html',results=dataId) 

@app.route('/postStore', methods=["POST", "GET"])
def postStore():
    if not session.get("email"):
        return redirect("/login")
    if request.method == "POST":
        title = request.form['title']
        publisher = request.form['name']
        file = request.files['file']
        path="static/Admin/Uploads/Posts"
        isExist = os.path.exists(path)
        if not isExist:
         os.mkdir(path)
        if file:
                   filename = secure_filename(file.filename)
                   file.save(os.path.join(path, filename)) 
                   cur = mysql.connection.cursor()
                   cur.execute("INSERT INTO post (title,publisher,file) VALUES (%s, %s,%s)", (title,publisher,filename))
                   mysql.connection.commit() 
   
    return render_template('index.html')  
  

#Suggestion Box details
@app.route('/suggestionBox')
def suggestionBox():
    if not session.get("email"):
        return redirect("/login")
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM contactus")
    data = cur.fetchall()
    cur.close() 

    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()             
    return render_template('/Admin/contactUs.html', result=data,results=dataId )


@app.route('/contactUs', methods = ['POST','GET'])
def contactus():
    if request.method == "GET":
        return "You are not allowed for this method please go to form and then submit ok."
    if request.method == "POST":
        flash("Data Inserted Successfully")
        name = request.form['name']
        email = request.form['email']
        subject=request.form['subject']
        message=request.form['message']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO contactus (name, email,subject,message) VALUES (%s, %s, %s, %s)", (name, email,subject,message))
        mysql.connection.commit()
        return redirect(url_for('suggestionBox'))

#View 
@app.route('/contactUsview/<id>')
def contactUsview(id):
       if not session.get("email"):
        return redirect("/login")
       cur = mysql.connection.cursor()
       cur.execute("SELECT  * FROM contactus WHERE id=%s", (id,))
       data = cur.fetchall()
       cur.close()
       Id=session.get("id")    
       cur = mysql.connection.cursor()
       cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
       dataId = cur.fetchall()
       cur.close()   
       return render_template('/Admin/contactUs.html', result=data,results=dataId )


#Delete
@app.route('/contactUsdelete/<id>', methods = ['GET'])
def delete(id):
    # return id
    flash("Record Has Been Deleted Successfully")
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM contactus WHERE id=%s", (id,))
    mysql.connection.commit()
    cur.close() 
    return redirect(url_for('suggestionBox'))






@app.route('/setcookie')
def setcookie():
    response = make_response(f"The Cookie has been Set Dinesh Raj Paudel")
    expire_date = datetime.datetime.now()
    expire_date = expire_date + datetime.timedelta(days=90)
    response.set_cookie('Username','dineshrajpaudel84@gmail.com', expires=expire_date)
    response.set_cookie('Password','Dinesh@2000', expires=expire_date)
 
    return response
 


@app.route("/Sessiondata")
def Sessiondata():
    return  "{}".format(session.get("email")) 

@app.route('/deletecookie')
def deletecookie():
    response = make_response()
    response.set_cookie('Username','', expires=0)
    response.set_cookie('Password','', expires=0)
    if response:
        return response
    else:
        return "Cookie doesnot delete"

@app.route('/getcookie')
def getcookie():
    userName = request.cookies.get('Username')
    passwords = request.cookies.get('Password')
    return f"The Site :{userName}  {passwords}"


@app.route('/setting')
def setting():
    Id=session.get("id")    
    cur = mysql.connection.cursor()
    cur.execute("SELECT  * FROM users WHERE id=%s", (Id,))
    dataId = cur.fetchall()
    cur.close()     
    return render_template('Admin/setting.html',results=dataId)  



if __name__ == "__main__":
    app.run(debug=True)
